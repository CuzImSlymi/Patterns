made by slymi

for the bluf and bamb stuff please use https://github.com/CuzImSlymi/Tad-Alt-Sync/releases

intended with haste, may have bugs. lmk